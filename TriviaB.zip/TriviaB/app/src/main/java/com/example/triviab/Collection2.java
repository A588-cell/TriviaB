package com.example.triviab;

import java.util.LinkedList;
import java.util.Queue;

public class Collection2 {

    private Queue<Question> queue;
    private int index; // מספר השאלה הבאה בתור

    public Collection2() {
        queue = new LinkedList<>();

        // יצירת השאלות
        Question q1 = new Question("1+10", "7", "11", "3", "100", 2);
        Question q2 = new Question("1+2", "8", "2", "3", "100", 3);
        Question q3 = new Question("1+3", "6", "2", "4", "100", 3);
        Question q4 = new Question("1+4", "5", "2", "3", "100", 1);
        Question q5 = new Question("1+0", "1", "2", "3", "100", 1);


        // הוספת השאלות לתור
        queue.add(q1);
        queue.add(q2);
        queue.add(q3);
        queue.add(q4);
        queue.add(q5);
    }

    public void initQuestions() {
        // לא צריך לשנות את הערך של index, זה לא רלוונטי כאן
        index = 0;
    }

    public Question getNextQuestion() {
        // שליפה של השאלה הראשונה בתור
        Question q = queue.poll(); // poll() מחזירה ומסירה את השאלה הראשונה בתור
        return q;
    }

    public boolean isNotLastQuestion() {
        // אם יש שאלות בתור, אנו לא בשאלה האחרונה
        return !queue.isEmpty();
    }

    public int getIndex() {
        // לא צריך לעדכן את index, מכיוון שהשאלות נשלפות לפי סדר
        return index;
    }
}

